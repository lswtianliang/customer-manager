/**
 * app容器
 */

import './App.less';
import Router from './common/routeConfig';

function App() {
  return <Router />;
}

export default App;
