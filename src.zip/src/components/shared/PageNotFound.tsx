import React from 'react';
import './PageNotFound.less';
export default function PageNotFound() {
  return <div className="common-page-not-found">404, Page not found</div>;
}
