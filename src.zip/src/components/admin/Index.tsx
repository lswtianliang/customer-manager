export default () => <h1>this is admin feature page, just for test.</h1>;
